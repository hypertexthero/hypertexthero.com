Made by Simon Griffee in January 2015 in New York City. 

Dedicated to the Public Domain: https://creativecommons.org/publicdomain/zero/1.0/

URL for more info: http://hypertexthero.com/logbook/2015/01/international-symbol-observer/